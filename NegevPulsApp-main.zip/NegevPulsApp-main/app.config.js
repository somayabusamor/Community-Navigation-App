export default {
  expo: {
    name: "myApp",
    slug: "myApp",
    version: "1.0.0",
    sdkVersion: "50.0.0", // حسب نسخة Expo اللي عندك
    extra: {
      GOOGLE_MAPS_API_KEY:  "AIzaSyDT1gfcevxFk8LTDp3R4zB4kPXJJOJz3Jo", // 🔐 ضع مفتاحك هنا
    },
  },
};
