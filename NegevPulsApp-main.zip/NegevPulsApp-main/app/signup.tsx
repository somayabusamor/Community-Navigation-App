import React from 'react';
import Signup from '@/frontend/components/signup';

export default function SignupScreen() {
  return <Signup />;
}
