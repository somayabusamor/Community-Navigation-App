import React from 'react';
import Landmarks from '@/frontend/components/landmarks';

export default function LoginScreen() {
  return <Landmarks />;
}
