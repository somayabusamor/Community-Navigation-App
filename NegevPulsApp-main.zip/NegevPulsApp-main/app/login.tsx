import React from 'react';
import Login from '@/frontend/components/login';

export default function LoginScreen() {
  return <Login />;
}
